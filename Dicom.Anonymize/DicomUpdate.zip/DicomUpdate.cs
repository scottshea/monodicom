using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;

using Dicom;
using Dicom.Data;

namespace Dicom.Anonymize
{
	public class DicomUpdate
	{
		public DicomFileFormat UpdateDicomFile(UpdateData updateData)
		{
			DicomFileFormat dicomFile = new DicomFileFormat();

			dicomFile.Load(updateData.DicomFilePath,DicomReadOptions.DeferLoadingLargeElements);
			
			foreach(KeyValuePair<DicomTag,string> kvp in updateData.UpdateDataset)
			{
				dicomFile.Dataset.SetString(kvp.Key, kvp.Value);
			}
			
			foreach(KeyValuePair<DicomTag,string> kvp in updateData.UpdateMetadata)
			{
				dicomFile.FileMetaInfo.SetString(kvp.Key, kvp.Value);
			}
			
			dicomFile.Dataset.PreloadDeferredBuffers();
            dicomFile.Save(updateData.DicomFilePath, DicomWriteOptions.Default);
			
			if (updateData.DicomFileName != null)
			{
				string path = Path.GetDirectoryName(updateData.DicomFilePath); 
				File.Move(updateData.DicomFilePath, path + @"\" + updateData.DicomFileName);
			}
		}
	}		
}

